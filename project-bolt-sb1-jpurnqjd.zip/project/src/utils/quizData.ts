export interface QuizStep {
  id: number;
  type: 'intro' | 'question' | 'info' | 'analysis' | 'reward';
  title: string;
  content: string;
  options?: string[];
  buttonText: string;
  awardsPoints?: boolean;
}

export const quizSteps: QuizStep[] = [
  {
    id: 1,
    type: 'intro',
    title: 'Bem-vindo à Caça aos Caramelinhos!',
    content: 'Responda às perguntas, colete Caramelinhos 🍬 e ganhe um SUPER presente no final! Preparada para começar essa jornada doce?',
    buttonText: 'SIM! QUERO MEUS CARAMELINHOS E MEU PRESENTE!',
    awardsPoints: false
  },
  {
    id: 2,
    type: 'question',
    title: 'Sobre Você e os Doces',
    content: 'Qual é a sua maior dificuldade quando pensa em viver de doces caramelizados?',
    options: [
      'Não sei por onde começar',
      'Tenho medo de não dar certo',
      'Não sei como vender/divulgar',
      'Receitas inconsistentes'
    ],
    buttonText: 'PRÓXIMA PERGUNTA',
    awardsPoints: true
  },
  {
    id: 3,
    type: 'question',
    title: 'Sua Experiência',
    content: 'Você já tentou vender doces caramelizados antes?',
    options: [
      'Nunca tentei, mas quero muito!',
      'Já tentei algumas vezes',
      'Vendo ocasionalmente',
      'Vendo regularmente mas quero crescer'
    ],
    buttonText: 'PRÓXIMA PERGUNTA',
    awardsPoints: true
  },
  {
    id: 4,
    type: 'question',
    title: 'Sua Meta',
    content: 'Quanto você gostaria de ganhar mensalmente com doces caramelizados?',
    options: [
      'Uma renda extra (até R$1.000)',
      'Um salário mínimo (R$1.000 a R$2.000)',
      'Um bom salário (R$2.000 a R$5.000)',
      'Uma renda completa (acima de R$5.000)'
    ],
    buttonText: 'PRÓXIMA PERGUNTA',
    awardsPoints: true
  },
  {
    id: 5,
    type: 'question',
    title: 'Seu Maior Sonho',
    content: 'O que você mais deseja conquistar com seu negócio de doces caramelizados?',
    options: [
      'Liberdade financeira',
      'Trabalhar com o que amo',
      'Flexibilidade de horários',
      'Reconhecimento profissional'
    ],
    buttonText: 'PRÓXIMA PERGUNTA',
    awardsPoints: true
  },
  {
    id: 6,
    type: 'info',
    title: 'Você Sabia?',
    content: 'O mercado de doces artesanais cresceu mais de 40% nos últimos 2 anos! 💡 Mais de 75% dos empreendedores de doces caramelizados que seguem um método estruturado conseguem atingir a independência financeira em menos de 1 ano!',
    buttonText: 'CONTINUAR',
    awardsPoints: false
  },
  {
    id: 7,
    type: 'question',
    title: 'Seu Maior Desafio',
    content: 'O que mais te impede de começar ou fazer seu negócio de doces crescer HOJE?',
    options: [
      'Falta de conhecimento técnico',
      'Medo de fracassar',
      'Falta de capital inicial',
      'Não saber como precificar'
    ],
    buttonText: 'PRÓXIMA PERGUNTA',
    awardsPoints: true
  },
  {
    id: 8,
    type: 'question',
    title: 'Seu Tempo Disponível',
    content: 'Quanto tempo você tem disponível para dedicar ao seu negócio de doces caramelizados semanalmente?',
    options: [
      'Poucas horas (1-5h)',
      'Meio período (10-20h)',
      'Quase tempo integral (20-30h)',
      'Tempo integral (30h+)'
    ],
    buttonText: 'PRÓXIMA PERGUNTA',
    awardsPoints: true
  },
  {
    id: 9,
    type: 'info',
    title: 'História de Sucesso',
    content: '"Antes eu vendia apenas para amigos e familiares. Após aplicar as técnicas do guia, em 3 meses já estava faturando R$3.500 por mês com meus doces caramelizados!" - Maria C., São Paulo 🌟',
    buttonText: 'CONTINUAR',
    awardsPoints: false
  },
  {
    id: 10,
    type: 'question',
    title: 'Sua Decisão',
    content: 'Você está pronta para transformar sua paixão por doces caramelizados em um negócio lucrativo?',
    options: [
      'Sim! Estou super motivada!',
      'Quero muito, mas tenho algumas dúvidas',
      'Talvez, preciso de mais informações',
      'Ainda não me sinto preparada'
    ],
    buttonText: 'FINALIZAR',
    awardsPoints: true
  },
  {
    id: 11,
    type: 'analysis',
    title: 'Contando Seus Caramelinhos...',
    content: 'Uau! Você conseguiu! Você juntou 70 Caramelinhos! 🍬🍬🍬 Seu presente está sendo embrulhado... e seu plano personalizado está sendo ajustado... Preparada?',
    buttonText: 'QUERO VER MEU PRESENTE!',
    awardsPoints: false
  },
  {
    id: 12,
    type: 'reward',
    title: 'Parabéns! Seus 70 Caramelinhos Valem Ouro (ou Melhor, um Super Desconto!)',
    content: 'Você foi incrível e merece seu presente! Por ter completado nossa jornada e juntado todos os Caramelinhos, você vai levar o Guia Completo "Viver de Doces Caramelizados" com um desconto SENSACIONAL!\n\nPreço Normal: ~R$82~\n\nSEU PREÇO DE PRESENTE: APENAS R$37!\n\n(Você economiza R$45!)\n\nEste é o nosso empurrãozinho para você começar HOJE a transformar sua cozinha numa fonte de renda doce e feliz!\n\n✅ 12 receitas exclusivas de doces caramelizados com alta margem de lucro\n✅ Guia completo de precificação para maximizar seus ganhos\n✅ Estratégias de venda testadas e aprovadas por centenas de alunas\n\n🎁 BÔNUS: Mentoria em grupo por 30 dias\n\n⚠️ Oferta por tempo limitado! Este desconto especial expira em breve!',
    buttonText: '🍬 RESGATAR MEU GUIA POR SÓ R$37 AGORA! 🍬',
    awardsPoints: false
  }
];