import React from 'react';
import { Candy } from 'lucide-react';
import QuizContainer from './components/QuizContainer';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-rose-50 text-gray-800 flex flex-col items-center">
      <QuizContainer />
    </div>
  );
}

export default App;