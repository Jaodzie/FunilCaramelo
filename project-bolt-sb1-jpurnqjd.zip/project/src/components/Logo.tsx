import React from 'react';
import { Candy } from 'lucide-react';

const Logo: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center py-4 scale-in">
      <div className="flex items-center mb-1">
        <Candy size={32} className="text-rose-600 mr-2" strokeWidth={2.5} />
        <h1 className="title-font text-xl text-rose-600">Caça aos Caramelinhos</h1>
      </div>
    </div>
  );
};

export default Logo;