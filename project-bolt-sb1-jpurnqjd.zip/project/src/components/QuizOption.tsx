import React from 'react';

interface QuizOptionProps {
  text: string;
  onClick: () => void;
  selected?: boolean;
}

const QuizOption: React.FC<QuizOptionProps> = ({ text, onClick, selected }) => {
  return (
    <button 
      className={`quiz-option ${selected ? 'border-rose-600 bg-rose-50' : ''}`}
      onClick={onClick}
    >
      {text}
    </button>
  );
};

export default QuizOption;