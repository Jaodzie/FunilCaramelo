import React, { useEffect, useState } from 'react';
import { Candy } from 'lucide-react';

interface CandyCounterProps {
  count: number;
  showAnimation: boolean;
  onAnimationComplete: () => void;
}

const CandyCounter: React.FC<CandyCounterProps> = ({ 
  count, 
  showAnimation, 
  onAnimationComplete 
}) => {
  const [animationKey, setAnimationKey] = useState(0);

  useEffect(() => {
    if (showAnimation) {
      setAnimationKey(prev => prev + 1);
      const timer = setTimeout(() => {
        onAnimationComplete();
      }, 600);
      return () => clearTimeout(timer);
    }
  }, [showAnimation, onAnimationComplete]);

  return (
    <div className="relative flex items-center justify-center">
      <div className="flex items-center bg-white px-3 py-1 rounded-full shadow-sm border border-rose-100">
        <span className="text-gray-700 font-semibold mr-1">Seus Caramelinhos:</span>
        <span className="text-rose-600 font-bold">{count}</span>
        <Candy size={18} className="text-rose-600 ml-1" />
      </div>
      
      {showAnimation && (
        <div 
          key={animationKey}
          className="candy-animation absolute text-rose-600 font-bold"
        >
          +10 🍬
        </div>
      )}
    </div>
  );
};

export default CandyCounter;