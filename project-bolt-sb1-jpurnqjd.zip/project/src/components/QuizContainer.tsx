import React, { useState, useEffect } from 'react';
import Logo from './Logo';
import ProgressBar from './ProgressBar';
import CandyCounter from './CandyCounter';
import Button from './Button';
import QuizOption from './QuizOption';
import SoundEffect from './SoundEffect';
import { quizSteps } from '../utils/quizData';

const QuizContainer: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [candyCount, setCandyCount] = useState(0);
  const [showCandyAnimation, setShowCandyAnimation] = useState(false);
  const [playCandySound, setPlayCandySound] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [fadeIn, setFadeIn] = useState(true);
  const [showAnalysisProgress, setShowAnalysisProgress] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);

  const totalSteps = quizSteps.length;
  const step = quizSteps.find(step => step.id === currentStep) || quizSteps[0];

  const handleOptionSelect = (option: string) => {
    setSelectedOption(option);
    if (step.type === 'question') {
      handleNextStep();
    }
  };

  const handleNextStep = () => {
    setFadeIn(false);
    
    setTimeout(() => {
      if (step.awardsPoints) {
        setCandyCount(prev => prev + 10);
        setShowCandyAnimation(true);
        if (!isMuted) {
          setPlayCandySound(true);
        }
      }
      
      setCurrentStep(prev => prev + 1);
      setSelectedOption(null);
      setFadeIn(true);
      
      if (currentStep === 10) {
        setShowAnalysisProgress(true);
      }
    }, 300);
  };

  const handleFinalCTA = () => {
    window.location.href = 'https://pay.cakto.com.br/inu7fcp_364110';
  };

  useEffect(() => {
    if (showAnalysisProgress) {
      const interval = setInterval(() => {
        setAnalysisProgress(prev => {
          const next = prev + 1;
          if (next >= 100) {
            clearInterval(interval);
            return 100;
          }
          return next;
        });
      }, 500); // Slower counting animation (0.5s per increment)
      
      return () => clearInterval(interval);
    }
  }, [showAnalysisProgress]);

  const renderFinalPage = () => {
    return (
      <div className="space-y-8">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="font-bold text-xl mb-4">O QUE VOCÊ LEVA:</h3>
          <ul className="space-y-3">
            <li className="flex items-start">
              <span className="text-green-600 mr-2">✔️</span>
              <span>Entrega imediata</span>
            </li>
            <li className="flex items-start">
              <span className="text-green-600 mr-2">✔️</span>
              <span>Técnicas para vender até R$200 por dia</span>
            </li>
            <li className="flex items-start">
              <span className="text-green-600 mr-2">✔️</span>
              <span>Aprenda a fazer o MELHOR CARAMELO DO MUNDO, casquinha fininha, que não gruda, derrete na boca e dura até 20 dias</span>
            </li>
            <li className="flex items-start">
              <span className="text-green-600 mr-2">✔️</span>
              <span>+ de 30 Receitas de Brigadeiro Caramelizado para você se destacar</span>
            </li>
            <li className="flex items-start">
              <span className="text-green-600 mr-2">✔️</span>
              <span>100% do material disponível para você ver quantas vezes for necessário</span>
            </li>
            <li className="flex items-start">
              <span className="text-green-600 mr-2">✔️</span>
              <span>Acompanhamento do seu desenvolvimento</span>
            </li>
            <li className="flex items-start">
              <span className="text-green-600 mr-2">✔️</span>
              <span>Precificação do seu produto</span>
            </li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="font-bold text-xl mb-4">BÔNUS ADICIONAIS:</h3>
          <ul className="space-y-3">
            <li className="flex items-start">
              <span className="text-green-600 mr-2">✔️</span>
              <span>BÔNUS 01 - Como Vender Via IFOOD</span>
            </li>
            <li className="flex items-start">
              <span className="text-green-600 mr-2">✔️</span>
              <span>BÔNUS 02 - Grupo da comunidade</span>
            </li>
          </ul>
        </div>

        <button onClick={handleFinalCTA} className="button-primary">
          🍬 RESGATAR MEU GUIA POR SÓ R$37 AGORA! 🍬
        </button>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="space-y-4">
              <div className="border-b pb-4">
                <p className="italic">"Recebi segundos depois que comprei! Eu não conseguia comprar presentes pros meu filhos, mas com essa renda extra finalmente posso dar oque eles merecem 😍🥰🥰🥰"</p>
                <p className="font-semibold mt-2">MARGARETE SILVA</p>
              </div>
              <div className="border-b pb-4">
                <p className="italic">"Comprei e recebi na hora! Eu estava precisando muito de uma renda extra e os doces caramelizados salvaram meu mês! As receitas são fáceis e os clientes elogiam demais"</p>
                <p className="font-semibold mt-2">FELICIA DE SOUSA</p>
              </div>
              <div>
                <p className="italic">"Vale cada centavo! Comprei achando que seria só mais um gasto ou golpe, mas me surpreendi. Tudo bem explicado, os doces ficam lindos e já estou vendendo pelo app do Ifood."</p>
                <p className="font-semibold mt-2">CLEUSA MARQUES GUERRA</p>
              </div>
            </div>
          </div>

          <button onClick={handleFinalCTA} className="button-primary">
            🍬 RESGATAR MEU GUIA POR SÓ R$37 AGORA! 🍬
          </button>

          <div className="flex justify-center">
            <img 
              src="https://i.imgur.com/XZOXjVY.png" 
              alt="7 dias de garantia" 
              className="w-24 h-24"
            />
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full max-w-md mx-auto p-4 flex flex-col min-h-screen">
      <div className="flex-none">
        <Logo />
        <ProgressBar currentStep={currentStep} totalSteps={totalSteps} />
        <div className="mt-3 mb-6 flex justify-center">
          <CandyCounter 
            count={candyCount} 
            showAnimation={showCandyAnimation} 
            onAnimationComplete={() => setShowCandyAnimation(false)} 
          />
        </div>
      </div>
      
      <div className={`flex-grow flex flex-col items-center justify-center ${fadeIn ? 'fade-in' : ''}`}>
        {currentStep === 12 ? (
          renderFinalPage()
        ) : (
          <>
            <h2 className="title-font text-2xl text-center mb-4 text-rose-700">{step.title}</h2>
            
            <div className="text-center mb-6 text-gray-700">
              {step.content.split('\n').map((line, i) => (
                <React.Fragment key={i}>
                  {line}
                  {i < step.content.split('\n').length - 1 && <br />}
                </React.Fragment>
              ))}
            </div>
            
            {step.type === 'question' && step.options && (
              <div className="w-full space-y-3 mb-6">
                {step.options.map((option, index) => (
                  <QuizOption 
                    key={index}
                    text={option}
                    onClick={() => handleOptionSelect(option)}
                    selected={selectedOption === option}
                  />
                ))}
              </div>
            )}
            
            {step.type === 'analysis' && showAnalysisProgress && (
              <div className="w-full max-w-sm mb-6">
                <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-rose-600 rounded-full transition-all duration-500" 
                    style={{ width: `${analysisProgress}%` }}
                  ></div>
                </div>
              </div>
            )}

            {step.type !== 'question' && (
              <Button 
                text={step.buttonText}
                onClick={handleNextStep}
                className={step.type === 'reward' ? 'bg-green-600 hover:bg-green-700' : ''}
              />
            )}
          </>
        )}
      </div>
      
      <div className="flex-none">
        <div className="flex justify-center mt-4">
          <button 
            onClick={() => setIsMuted(prev => !prev)} 
            className="text-gray-500 text-sm flex items-center"
          >
            {isMuted ? '🔇 Som desligado' : '🔊 Som ligado'}
          </button>
        </div>
      </div>
      
      <SoundEffect 
        play={playCandySound} 
        onComplete={() => setPlayCandySound(false)} 
      />
    </div>
  );
};

export default QuizContainer;