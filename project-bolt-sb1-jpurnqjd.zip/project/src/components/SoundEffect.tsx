import React, { useEffect, useRef } from 'react';

interface SoundEffectProps {
  play: boolean;
  onComplete: () => void;
}

const SoundEffect: React.FC<SoundEffectProps> = ({ play, onComplete }) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  
  useEffect(() => {
    if (play && audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(e => console.log("Audio play failed:", e));
      onComplete();
    }
  }, [play, onComplete]);

  return (
    <audio 
      ref={audioRef}
      src="https://assets.mixkit.co/sfx/preview/mixkit-coin-win-notification-1992.mp3"
      preload="auto"
    />
  );
};

export default SoundEffect;